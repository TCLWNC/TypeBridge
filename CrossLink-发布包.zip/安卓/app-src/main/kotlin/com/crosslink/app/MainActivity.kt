package com.crosslink.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.io.File
import org.json.JSONObject
import kotlin.concurrent.thread

/* 配色取自 LocalSend 源码 app/lib/config/theme.dart：
   ColorScheme.fromSeed(seedColor: Colors.teal) + ColorMode.oled(surface: Colors.black)；
   圆角取自同文件 _borderRadius = BorderRadius.circular(5)。 */
private const val C_BG = 0xFF000000.toInt()       // OLED：纯黑
private const val C_CARD = 0xFF1A1B21.toInt()     // M3 dark surfaceContainer
private const val C_INPUT = 0xFF101116.toInt()
private const val C_LINE = 0x22FFFFFF
private const val C_TEXT = 0xFFFFFFFF.toInt()
private const val C_DIM = 0xFFC7C9D4.toInt()
private const val C_MUTED = 0xFF8B8E9D.toInt()
private const val C_PRIMARY = 0xFFB4C5FF.toInt()  // M3 dark primary（teal 种子）
private const val C_ON_PRIMARY = 0xFF0B2A5B.toInt()
private const val C_OK = 0xFF4CD07D.toInt()
private const val C_BRAND = 0xFF00AEFA.toInt()
private const val C_BAD = 0xFFFF6B6B.toInt()
private const val C_CHIP_ON = 0x2AB4C5FF

class MainActivity : Activity() {

    private lateinit var client: Client
    private var sid = ""
    private var sent = ""
    private var lastSent = ""
    private var liveMode = true
    private var enterAfter = false
    private val device: String = (Build.MODEL ?: "手机").ifBlank { "手机" }

    private lateinit var root: LinearLayout
    private lateinit var input: EditText
    private lateinit var counter: TextView
    private lateinit var notice: TextView
    private lateinit var targetText: TextView
    private lateinit var pcName: TextView
    private lateinit var sendBtn: Button
    private lateinit var liveBtn: TextView
    private lateinit var batchBtn: TextView
    private var addrField: EditText? = null
    private var pinField: EditText? = null
    private var deviceList: LinearLayout? = null
    private var statusLine: TextView? = null
    private var manualBox: LinearLayout? = null
    private var refreshBar: ProgressBar? = null
    private var emptyHint: TextView? = null
    private val found = LinkedHashMap<String, Discovery.Found>()
    private val lastSeen = HashMap<String, Long>()
    private val logs = mutableListOf<String>()
    private var tabSend: View? = null
    private var tabLogs: View? = null
    private var tabCfg: View? = null
    private var tabButtons = mutableMapOf<String, Button>()
    private var tabItems = mutableMapOf<String, Triple<View, TextView, View>>()
    private var lastSignature = ""
    @Volatile private var discovering = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 崩溃自查：把所有未捕获异常写到文件，并在屏幕上显示原因，
        // 这样即使我没有真机，下一次也能拿到确切错误而不是靠猜。
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            runCatching {
                File(filesDir, "crash.txt").appendText(
                    "\n==== ${java.util.Date()} ====\n" + android.util.Log.getStackTraceString(e))
            }
        }
        window.statusBarColor = C_BG
        window.navigationBarColor = C_BG
        try {
            buildShell()
        } catch (e: Throwable) {
            showCrash(e)
        }
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C_BG)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        setContentView(root)
        showDevices()
    }

    /** 出问题时不闪退，把原因显示出来（可滚动）。 */
    private fun showCrash(e: Throwable) {
        val text = android.util.Log.getStackTraceString(e)
        runCatching {
            File(filesDir, "crash.txt").appendText("\n==== ${java.util.Date()} ====\n$text")
        }
        val tv = TextView(this).apply {
            this.text = "启动出错，请把下面这段发给我：\n\n$text"
            textSize = 12.5f
            setTextColor(C_BAD)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        setContentView(ScrollView(this).apply { addView(tv) })
    }

    override fun onResume() {
        super.onResume()
        if (!connectedOnce) startDiscovery()
    }

    override fun onPause() {
        super.onPause()
        discovering = false
    }

    private var connectedOnce = false

    /** 打开就在搜，并且一直刷新——这才叫设备列表。 */
    private fun startDiscovery() {
        if (discovering) return
        discovering = true
        thread {
            var lastScanAt = 0L
            while (discovering) {
                val list = runCatching { Discovery.search(port = 8788, timeoutMs = 1500) }
                    .getOrDefault(emptyList())
                // 兜底扫 /24 很贵（254 × 若干端口），所以：
                // 只在「一直搜不到」且距上次扫描超过 15 秒时才扫，避免手机发热、掉电
                val now = System.currentTimeMillis()
                val scanned = if (list.isEmpty() && found.isEmpty() && now - lastScanAt > 15_000) {
                    lastScanAt = now
                    runCatching { Discovery.scanSubnet(port = 8788) }.getOrDefault(emptyList())
                } else emptyList()
                runOnUiThread {
                    if (!discovering) return@runOnUiThread
                    (list + scanned).forEach { found["${it.host}:${it.port}"] = it }
                    val nowMs = System.currentTimeMillis()
                    found.keys.forEach { lastSeen[it] = nowMs }
                    // 超过 12 秒没再出现的设备要从列表里清掉（之前断了也一直挂着）
                    val stale = lastSeen.filterValues { nowMs - it > 12_000 }.keys.toList()
                    if (stale.isNotEmpty()) {
                        stale.forEach { found.remove(it); lastSeen.remove(it) }
                        logs.add("移除 ${stale.size} 台已断开的设备")
                        lastSignature = ""
                    }
                    if (scanned.isNotEmpty()) {
                        logs.add("网段扫描找到 ${scanned.size} 台电脑")
                    }
                    renderDevices()
                }
                runCatching { Thread.sleep(1200) }
            }
        }
    }

    private fun renderDevices() {
        val box = deviceList ?: return
        val st = statusLine ?: return
        val keys = found.keys.sorted()
        // 签名里必须带上「是否需要配对码」：否则电脑上关掉配对码后，
        // 手机列表因为签名没变而不重绘，仍按旧状态弹配对码。
        val sig = keys.joinToString("|") { "$it:${found[it]?.needPin}" }
        refreshBar?.visibility = if (discovering && found.isEmpty()) View.VISIBLE else View.GONE

        // 列表没变化就直接返回：不重建、不重放动画，整片列表保持静止
        if (sig == lastSignature) return
        val previous = lastSignature.split("|").filter { it.isNotEmpty() }.toSet()
        lastSignature = sig

        box.removeAllViews()
        val text = if (found.isEmpty()) "正在搜索同一 Wi-Fi 下的电脑" else "找到 ${found.size} 台电脑"
        if (st.text.toString() != text) {
            st.text = text
            st.alpha = 0.4f
            st.animate().alpha(1f).setDuration(220L).start()
        }
        emptyHint?.visibility = if (found.isEmpty()) View.VISIBLE else View.GONE
        if (found.isEmpty()) {
            return
        }
        keys.forEachIndexed { index, key ->
            val dev = found[key] ?: return@forEachIndexed
            val row = deviceRow(dev) { connectTo("${dev.host}:${dev.port}", dev.needPin) }
            box.addView(row, lp(top = 8, matchWidth = true))
            // 只有这一轮新出现的设备才做入场动画；已存在的行直接显示
            if (key !in previous) enter(row, delayMs = index * 40L)
        }
    }

    private fun showDevices() {
        root.removeAllViews()
        root.gravity = Gravity.TOP
        found.clear()

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        page.addView(label("跨屏输入", 22f, C_TEXT, true))
        page.addView(label("手机当电脑的无线键盘", 12.5f, C_MUTED))

        /* ---- 卡片一：附近的电脑 ---- */
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(C_CARD, 16f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(label("附近的电脑", 13f, C_MUTED, true))
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }, LinearLayout.LayoutParams(0, 1, 1f))
        refreshBar = ProgressBar(this).apply {
            visibility = View.VISIBLE
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        }
        head.addView(refreshBar)
        card.addView(head)

        statusLine = label("正在搜索同一 Wi-Fi 下的电脑…", 12.5f, C_BRAND)
        card.addView(statusLine, lp(top = 8, matchWidth = true))

        // 只剩一句提示：列表本身才是主角，不要把首页堆成说明书
        emptyHint = label("没搜到 · 检查同一 Wi-Fi 和电脑端防火墙", 12f, C_MUTED)
        card.addView(emptyHint, lp(top = 8, matchWidth = true))

        deviceList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(deviceList, lp(top = 8, matchWidth = true))
        renderDevices()
        page.addView(card, lp(top = 16, matchWidth = true))

        /* ---- 卡片二：连接设置（一直显示，不折叠）---- */
        val cfg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(C_CARD, 16f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        cfg.addView(label("连接设置", 13f, C_MUTED, true))
        cfg.addView(label("地址和配对码和电脑窗口上显示的一致；配对码只有电脑开了「需要配对码」时才要填。",
            12f, C_MUTED), lp(top = 8, matchWidth = true))

        val addr = EditText(this).apply {
            hint = "电脑地址，例如 192.168.1.146:8788"
            setText("192.168.1.146:8788")
            setTextColor(C_TEXT); setHintTextColor(C_MUTED)
            background = pressable(C_INPUT, 14f, C_LINE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val pin = EditText(this).apply {
            hint = "配对码（电脑没开就留空）"
            setTextColor(C_TEXT); setHintTextColor(C_MUTED)
            background = pressable(C_INPUT, 14f, C_LINE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val go = Button(this).apply {
            text = "连接电脑"
            setTextColor(C_ON_PRIMARY)
            textSize = 14f
            background = pressable(C_PRIMARY, 999f)
            setOnClickListener {
                connectTo(addr.text.toString().trim(), pin.text.toString().trim().isNotEmpty())
            }
        }
        // 这里必须先创建容器再往里放控件：上一版把创建那几行删了，
        // 却留着 manualBox!!，启动就 NPE（MainActivity.kt:244）。
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        manualBox = box
        box.addView(addr, lp(top = 8, matchWidth = true))
        box.addView(pin, lp(top = 8, matchWidth = true))
        cfg.addView(box, lp(top = 8, matchWidth = true))

        val opt = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val swAuto = Switch(this).apply {
            isChecked = enterAfter
            setOnCheckedChangeListener { _, v -> enterAfter = v }
        }
        opt.addView(swAuto)
        opt.addView(label("发送后自动回车", 13f, C_DIM))
        opt.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        opt.addView(chip("立即搜索") {
            found.clear()
            lastSignature = ""
            renderDevices()
            startDiscovery()
        })
        cfg.addView(opt, lp(top = 8, matchWidth = true))
        cfg.addView(go, lp(top = 8, h = 46, matchWidth = true))
        cfg.addView(label("v1.0.0 · 即打即输 / 编辑后发送 / 16 个功能键", 11.5f, C_MUTED),
            lp(top = 8, matchWidth = true))
        // 「发送后自动回车」和「断开」放进设置页（输入页保持干净）
        val setRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(48)
        }
        setRow.addView(Switch(this).apply {
            isChecked = enterAfter
            setOnCheckedChangeListener { _, v -> enterAfter = v }
        })
        setRow.addView(label("发送后自动回车", 14f, C_DIM))
        setRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        cfg.addView(setRow, lp(top = 8, matchWidth = true))
        // 发送模式挪到设置页：即打即输 / 编辑后发送
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(48)
        }
        modeRow.addView(label("发送模式", 14f, C_DIM))
        modeRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        liveBtn = tabButton("即打即输")
        batchBtn = tabButton("编辑后发送")
        liveBtn.setOnClickListener { liveMode = true; syncMode() }
        batchBtn.setOnClickListener { liveMode = false; syncMode() }
        modeRow.addView(liveBtn, LinearLayout.LayoutParams(dp(96), dp(40)))
        modeRow.addView(batchBtn, LinearLayout.LayoutParams(dp(112), dp(40)))
        cfg.addView(modeRow, lp(top = 8, matchWidth = true))
        cfg.addView(TextView(this).apply {
            text = "断开当前连接"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(C_BAD)
            background = pressable(C_INPUT, 12f, C_LINE)
            isClickable = true
            setOnClickListener {
                runCatching { client.close() }
                connectedOnce = false
                logs.add("已断开连接")
                showDevices()
            }
        }, lp(top = 8, h = 48, matchWidth = true))
        page.addView(cfg, lp(top = 16, matchWidth = true))

        addrField = addr
        pinField = pin

        val err = label("", 13f, C_BAD)
        page.addView(err, lp(top = 8, matchWidth = true))
        this.errLabel = err

        val scroll = ScrollView(this).apply { addView(page) }
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        /* ---- 底部栏（对应 LocalSend 手机端的 NavigationBar：发送 / 记录 / 设置）---- */
        tabSend = card
        tabCfg = cfg
        tabLogs = buildLogCard()
        page.addView(tabLogs, lp(top = 16, matchWidth = true))
        tabLogs?.visibility = View.GONE

        // 底部栏：只用「图标 + 文字 + 一条 3dp 下划线」表示选中，
        // 不再给按钮加整块圆角背景（那就是你说的"斜着的长方形"）。
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C_INPUT)
            setPadding(0, dp(8), 0, dp(10))
        }
        listOf(
            Triple("send", "发送", 0),
            Triple("logs", "记录", 0),
            Triple("cfg", "设置", 0),
        ).forEach { (key, label, icon) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                setOnClickListener { switchTab(key) }
            }
            // 三个图标用同一套自绘矢量（同 24 视口 / 同线宽），并强制 24×24dp —— 尺寸必然一致
            val iconView = android.widget.ImageView(this).apply {
                setImageResource(
                    when (key) {
                        "send" -> R.drawable.ic_tab_send
                        "logs" -> R.drawable.ic_tab_logs
                        else -> R.drawable.ic_tab_settings
                    })
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
                alpha = if (key == "send") 1f else 0.6f
            }
            val labelView = TextView(this).apply {
                text = label
                textSize = 11f
                gravity = Gravity.CENTER
                includeFontPadding = false     // 去掉字体自带留白，图标和文字才会对齐
                setTextColor(if (key == "send") C_PRIMARY else C_MUTED)
            }
            val underline = View(this).apply {
                setBackgroundColor(if (key == "send") C_PRIMARY else 0x00000000)
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(3))
                    .apply { topMargin = dp(3) }
            }
            item.addView(iconView)
            item.addView(labelView)
            item.addView(underline)
            item.layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f)
            item.tag = underline
            bar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            tabButtons[key] = Button(this)   // 占位，保持下面的逻辑不改
            tabItems[key] = Triple(iconView, labelView, underline)
        }
        root.addView(bar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        logs.add("打开应用，开始搜索")
        // 关键：初始化时只显示「发送」页的内容。
        // 之前漏了这一步，导致「连接设置」卡片默认堆在发送页上，
        // 「设置」Tab 里反而看到同样的东西。
        switchTab("send")
        enter(page, 0L)
        startDiscovery()
    }

    /** 底部栏切换：发送（设备列表）/ 记录 / 设置 */
    private fun switchTab(key: String) {
        if (key == "logs") renderLogCard()
        val target = when (key) {
            "send" -> tabSend
            "logs" -> tabLogs
            else -> tabCfg
        }
        listOf(tabSend, tabLogs, tabCfg).forEach { panel ->
            if (panel !== target) panel?.visibility = View.GONE
        }
        // 切换时淡入 + 上移 10dp，220ms 减速；不是"啪"地一下换掉
        target?.visibility = View.VISIBLE
        enter(target, 0L)
        tabButtons.forEach { (k, b) ->
            tabItems[k]?.let { (iconView, labelView, underline) ->
                val on = k == key
                labelView.setTextColor(if (on) C_PRIMARY else C_MUTED)
                underline.setBackgroundColor(if (on) C_PRIMARY else 0x00000000)
                iconView.alpha = if (on) 1f else 0.65f
            }
        }
    }

    private var logText: TextView? = null

    private fun buildLogCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(C_CARD, 16f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        card.addView(label("运行记录", 13f, C_MUTED, true))
        card.addView(label("连接、搜索、发送的动作都会记在这里，方便排查。", 12f, C_MUTED),
            lp(top = 8, matchWidth = true))
        logText = label("", 12f, C_DIM)
        card.addView(logText, lp(top = 8, matchWidth = true))
        return card
    }

    private fun renderLogCard() {
        logText?.text = if (logs.isEmpty()) "（空）"
        else logs.takeLast(40).reversed().joinToString("\n") { "· $it" }
    }

    private var errLabel: TextView? = null

    private fun connectTo(rawAddr: String, needPin: Boolean) {
        val addr = if (rawAddr.startsWith("http")) rawAddr else "http://$rawAddr"
        val pin = pinField?.text?.toString()?.trim().orEmpty()
        if (needPin && pin.isEmpty()) {
            askPin(rawAddr)      // 需要配对码就直接弹输入框，不再只给一行小字提示
            return
        }
        errLabel?.text = ""
        discovering = false
        thread {
            runCatching {
                client = Client(addr.trimEnd('/'))
                val res = client.hello(device, pin, androidId())
                if (res.optBoolean("ok")) {
                    sid = res.optString("sid")
                    connectedOnce = true
                    runOnUiThread {
                        try {
                            window.setSoftInputMode(
                                android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                            showInput(res.optString("pc", "电脑"))
                        } catch (e: Throwable) {
                            // 进输入页时出问题也别闪退，把原因留在屏幕上
                            val msg = "进入输入页出错：" + e
                            logs.add(msg)
                            errLabel?.text = msg
                        }
                    }
                    client.listen(sid) { ev -> onEvent(ev) }
                    // 心跳：每 5 秒告诉电脑端"我还在"，这样手机关掉/断网后
                    // 电脑端 12 秒内就会把设备移除（不依赖 SSE 是否带 sid）
                    thread {
                        while (connectedOnce) {
                            runCatching {
                                client.op(sid, listOf(JSONObject().put("k", "ping")))
                            }
                            runCatching { Thread.sleep(5000) }
                        }
                    }
                } else {
                    runOnUiThread { errLabel?.text = res.optString("error", "连接失败"); startDiscovery() }
                }
            }.onFailure {
                runOnUiThread { errLabel?.text = "连不上：${it.message}"; startDiscovery() }
            }
        }
    }

    private fun showInput(pc: String) {
        root.removeAllViews()
        root.gravity = Gravity.TOP

        pcName = label(pc, 18f, C_TEXT, true)
        targetText = label("先在电脑上点一下要输入的窗口", 12f, C_MUTED)
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        head.addView(pcName)
        head.addView(targetText)
        root.addView(head)

        input = EditText(this).apply {
            hint = "在这里打字…"
            setTextColor(C_TEXT); setHintTextColor(C_MUTED)
            textSize = 17f
            gravity = Gravity.TOP
            background = rounded(C_CARD, 12f, C_LINE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minimumHeight = dp(96)   // 键盘弹出时输入框要能被压缩，否则下面按钮会被挤出屏幕
        }
        root.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(12) })

        counter = label("0 字", 12f, C_MUTED)
        root.addView(counter, lp(top = 8, matchWidth = true))

        // 功能键收成一个按钮，点开是一个面板（不再占着屏幕一排）
        // 功能键只留一个入口按钮，点开是面板（屏幕上不再排一长条按键）
        val keyBar = TextView(this).apply {
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_keys, 0, 0, 0)
            compoundDrawablePadding = dp(10)
            text = "多按键"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(C_DIM)
            background = pressable(C_CARD, 12f, C_LINE)
            setPadding(dp(14), 0, dp(14), 0)
            isClickable = true
            setOnClickListener { showKeysDialog() }
        }
        // 一行四格：删除 | 恢复（略宽） | 输入（撑满中间） | 多按键
        val clearBtn = iconButton(R.drawable.ic_delete_trash, "删除") {
            input.setText(""); sent = ""; counter.text = "0 字"
            if (this@MainActivity::notice.isInitialized) notice.text = "已清空手机输入框（电脑上的内容没动）"
        }
        val restoreBtn = iconButton(R.drawable.ic_restore_undo, "恢复") {
            if (lastSent.isEmpty()) if (this@MainActivity::notice.isInitialized) notice.text = "还没有发送过内容"
            else { input.setText(lastSent); sent = lastSent; if (this@MainActivity::notice.isInitialized) notice.text = "已恢复上次发送的内容" }
        }
        sendBtn = Button(this).apply {
            text = "发送"
            textSize = 14f
            setTextColor(C_ON_PRIMARY)
            background = pressable(C_PRIMARY, 12f)
            setOnClickListener {
                // 按你说的：这个键就是敲一次回车；文本同步由输入框实时完成
                send(listOf(JSONObject().put("k", "key").put("key", "ENTER")))
                if (this@MainActivity::notice.isInitialized) notice.text = "已敲回车"
            }
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(clearBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
        actions.addView(restoreBtn, LinearLayout.LayoutParams(dp(64), dp(48)).apply { leftMargin = dp(8) })
        // 多按键已取消：中间只留「发送」（敲回车），左边删除、恢复
        actions.addView(sendBtn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        root.addView(actions, lp(top = 8, matchWidth = true))
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                counter.text = "${s?.length ?: 0} 字"
                if (liveMode) flush()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        syncMode()
    }

    private fun syncMode() {
        liveBtn.background = pressable(if (liveMode) C_CHIP_ON else 0x00000000, 12f)
        batchBtn.background = pressable(if (!liveMode) C_CHIP_ON else 0x00000000, 12f)
        liveBtn.setTextColor(if (liveMode) C_PRIMARY else C_MUTED)
        batchBtn.setTextColor(if (!liveMode) C_PRIMARY else C_MUTED)
        // 安全调用：设置页的「发送模式」在未连接时也能点，那时 sendBtn 还没创建，
        // 直接写属性会空指针闪退（你反馈的切换输入方式闪退就是这个）。
        if (this::sendBtn.isInitialized) sendBtn.text = "输入"
    }

    /** 功能键面板：点一个发一个，面板留着方便连点，右上角关闭。 */
    private fun showKeysDialog() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }
        col.addView(label("多按键", 15f, C_TEXT, true))
        col.addView(label("点一个发一个，面板不会自动关", 12f, C_MUTED), lp(top = 8, matchWidth = true))
        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        KEYS.chunked(4).forEach { rowKeys ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowKeys.forEach { (name, op) ->
                row.addView(chip(name) { send(listOf(op)) },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { rightMargin = dp(6); topMargin = dp(6) })
            }
            while (row.childCount < 4) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            grid.addView(row)
        }
        col.addView(grid, lp(top = 8, matchWidth = true))
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("关闭", null)
            .create()
        dialog.show()
    }

    /** 搜索结果里的一行：点一下就连过去 */
    /** 设备行：照 LocalSend 的 device_list_tile.dart 排——左边 46 的设备图标、
     *  20px 名字、下面一排徽章（HTTP / 地址:端口 / 需要配对码）、右边详情按钮；
     *  整行点一下就是连接。 */
    private fun deviceRow(dev: Discovery.Found, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = pressable(C_INPUT, 12f, C_LINE)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            minimumHeight = dp(64)
            isClickable = true
            setOnClickListener {
                // 兜底：点设备→连接这条路上任何异常都显示出来，不要直接闪退
                try {
                    onClick()
                } catch (e: Throwable) {
                    val msg = "连接出错：" + e
                    logs.add(msg)
                    notice?.text = msg
                    errLabel?.text = msg
                }
            }
        }
        // 左：设备图标 46
        row.addView(TextView(this).apply {
            setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.ic_computer, 0, 0)
            text = ""
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        })
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), 0, 0, 0)
        }
        col.addView(label(dev.name, 17f, C_TEXT, true))
        // 副标题只留一行地址（超长省略号），保持简约整齐
        col.addView(TextView(this).apply {
            text = "${dev.host}:${dev.port}"
            textSize = 12.5f
            setTextColor(C_MUTED)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(8), 0, 0)
        })
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        // 需要配对码时，右侧出现一个小标签；不需要就什么都不显示（更整洁）
        if (dev.needPin) {
            row.addView(TextView(this).apply {
                text = "需要配对码"
                textSize = 11f
                setTextColor(C_PRIMARY)
                background = rounded(C_CHIP_ON, 6f)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                gravity = Gravity.CENTER
            })
        }
        return row
    }

    /** 徽章：底色用主色低透明 + 描边，和 LocalSend 的 DeviceBadge 一个意思。 */
    private fun badge(text: String, high: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(if (high) C_PRIMARY else C_DIM)
            background = rounded(if (high) C_CHIP_ON else 0x1AFFFFFF.toInt(), 6f, C_LINE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            (layoutParams as? LinearLayout.LayoutParams)?.rightMargin = dp(6)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(6) }
        }

    private fun showDeviceInfo(dev: Discovery.Found) {
        android.app.AlertDialog.Builder(this)
            .setTitle(dev.name)
            .setMessage(
                "地址：${dev.host}\n端口：${dev.port}\n" +
                    "配对码：${if (dev.needPin) "需要（在电脑窗口上）" else "不需要"}"
            )
            .setPositiveButton("连接") { _, _ -> connectTo("${dev.host}:${dev.port}", dev.needPin) }
            .setNegativeButton("关闭", null)
            .show()
    }

    /** 需要配对码时弹输入框：输入 4 位后自动连；填错就地提示重试。 */
    private fun askPin(rawAddr: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val input = EditText(this).apply {
            hint = "4 位配对码"
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(C_TEXT)
            setHintTextColor(C_MUTED)
            background = rounded(C_INPUT, 12f, C_LINE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            textSize = 17f
            gravity = Gravity.CENTER
            maxEms = 4
        }
        box.addView(input)
        box.addView(TextView(this).apply {
            text = "配对码在电脑窗口上（输入页和设置页都显示）"
            textSize = 12.5f
            setTextColor(C_MUTED)
            setPadding(0, dp(8), 0, 0)
        })
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("这台电脑需要配对码")
            .setView(box)
            .setPositiveButton("连接", null)
            .setNegativeButton("取消", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val code = input.text.toString().trim()
                if (code.length < 4) {
                    input.error = "请输入 4 位配对码"
                    return@setOnClickListener
                }
                pinField?.setText(code)
                dialog.dismiss()
                connectTo(rawAddr, false)   // 配对码已写进输入框，直接连
            }
        }
        dialog.show()
    }

    private fun onEvent(ev: JSONObject) {
        val type = ev.optString("type")
        if (type == "state" || type == "settings") {
            val s = if (type == "settings") ev.optJSONObject("state") else ev
            val name = s?.optJSONObject("app")?.optString("name").orEmpty()
            if (name.isNotEmpty()) runOnUiThread { if (::pcName.isInitialized) pcName.text = name }
        }
        val target = when (type) {
            "target" -> ev.optJSONObject("target")
            "state" -> ev.optJSONObject("target")
            "settings" -> ev.optJSONObject("state")?.optJSONObject("target")
            else -> null
        } ?: return
        val app = target.optString("app")
        val title = target.optString("title")
        val ready = app.isNotEmpty() && !target.optBoolean("self")
        runOnUiThread {
            if (!::targetText.isInitialized) return@runOnUiThread
            targetText.text = when {
                app.isEmpty() -> "先在电脑上点一下要输入的窗口"
                target.optBoolean("self") -> "焦点在 CrossLink 上，点一下目标程序"
                else -> "已就绪：${title.ifEmpty { app }}"
            }
            targetText.setTextColor(if (ready) C_OK else C_MUTED)
        }
    }

    private fun send(ops: List<JSONObject>) {
        thread {
            val res = runCatching { client.op(sid, ops) }.getOrNull()
            // 电脑端把我们断开（或重启）后，手机端要自动退回设备列表，不能停在输入页
            val err = res?.optString("error").orEmpty()
            if (res != null && !res.optBoolean("ok", true) && err.contains("会话")) {
                runOnUiThread {
                    logs.add("电脑端已断开连接，返回设备列表")
                    connectedOnce = false
                    runCatching { client.close() }
                    showDevices()
                }
            }
        }
    }

    /** 安卓返回键：在输入页时退回设备列表，而不是直接退出应用 */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (connectedOnce) {
            runCatching { client.close() }
            connectedOnce = false
            logs.add("已断开连接，返回设备列表")
            showDevices()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    private fun flush() {
        // 250ms 防抖：连续打字时不逐字发，停手后才同步一次，
        // 否则电脑端会一直"全选→粘贴"，看起来就是在反复重刷。
        syncHandler.removeCallbacks(syncTask)
        syncHandler.postDelayed(syncTask, 250)
    }

    private val syncHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val syncTask = Runnable { flushNow() }

    private fun flushNow() {
        // 整段同步：不再算差量（差量会因电脑端光标位置而串位），
        // 直接把手机上输入框的完整内容交给电脑端，由电脑端负责变成这段文字。
        val now = input.text.toString()
        if (now == sent) return
        sent = now
        // 记录"上一次发到电脑的内容"，供「恢复」使用。
        // 之前只有发送键会写入它，而发送键早就改成只敲回车了，
        // 于是「恢复」永远是空的（用户反馈的"纯空壳"就是这个原因）。
        if (now.isNotEmpty()) lastSent = now
        send(listOf(JSONObject().put("k", "sync").put("text", now)))
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun chip(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(C_DIM)
            background = pressable(C_CARD, 999f, C_LINE)
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { onClick() }
        }

    /** 纯图标按钮（清空 / 还原这些） */
    /** 顶部页签（即打即输 / 编辑后发送）：选中 = 主色文字 + 底部 16×3 下划线 */
    private fun tabButton(text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(C_MUTED)
            background = pressable(0x00000000, 12f)
            isClickable = true
        }

    private fun iconButton(iconRes: Int, desc: String, onClick: () -> Unit): ImageButton =
        ImageButton(this).apply {
            // 用 ImageButton + scaleType=centerInside：图标严格居容器中心，
            // 不会像 TextView 的 compoundDrawable 那样受字体留白影响而"偏"。
            setImageResource(iconRes)
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            contentDescription = desc
            background = pressable(C_CARD, 12f, C_LINE)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
                .apply { leftMargin = dp(8); rightMargin = 0 }
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { onClick() }
        }

    private fun rounded(color: Int, radiusDp: Float, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radiusDp * resources.displayMetrics.density
            if (stroke != 0) setStroke(1, stroke)
        }

    /** 按压反馈：底色不变，按下时浮出一层白色涟漪（就是你要的「点击显白」）。 */
    private fun pressable(color: Int, radiusDp: Float, stroke: Int = 0): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(0x40FFFFFF),
            rounded(color, radiusDp, stroke), null)

    /** 内容入场：淡入 + 轻微上移，220ms 减速曲线。 */
    private fun enter(view: View?, delayMs: Long = 0L) {
        view ?: return
        view.alpha = 0f
        view.translationY = dp(10).toFloat()
        view.animate().alpha(1f).translationY(0f)
            .setStartDelay(delayMs).setDuration(220L)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun lp(top: Int = 0, h: Int = 0, matchWidth: Boolean = false): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            if (matchWidth) ViewGroup.LayoutParams.MATCH_PARENT
            else ViewGroup.LayoutParams.WRAP_CONTENT,
            if (h > 0) dp(h) else ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) }

    /** 本机唯一标识：用系统 ANDROID_ID，电脑端据此认出是同一台手机 */
    private fun androidId(): String = runCatching {
        android.provider.Settings.Secure.getString(contentResolver,
            android.provider.Settings.Secure.ANDROID_ID)
    }.getOrNull().orEmpty()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private val KEYS: List<Pair<String, JSONObject>> = listOf(
            "⌫" to JSONObject().put("k", "key").put("key", "BACKSPACE"),
            "⏎" to JSONObject().put("k", "key").put("key", "ENTER"),
            "Tab" to JSONObject().put("k", "key").put("key", "TAB"),
            "Esc" to JSONObject().put("k", "key").put("key", "ESC"),
            "←" to JSONObject().put("k", "key").put("key", "LEFT"),
            "↑" to JSONObject().put("k", "key").put("key", "UP"),
            "↓" to JSONObject().put("k", "key").put("key", "DOWN"),
            "→" to JSONObject().put("k", "key").put("key", "RIGHT"),
            "行首" to JSONObject().put("k", "key").put("key", "HOME"),
            "行尾" to JSONObject().put("k", "key").put("key", "END"),
            "全选" to JSONObject().put("k", "combo").put("key", "A").put("ctrl", true),
            "复制" to JSONObject().put("k", "combo").put("key", "C").put("ctrl", true),
            "粘贴" to JSONObject().put("k", "combo").put("key", "V").put("ctrl", true),
            "撤销" to JSONObject().put("k", "combo").put("key", "Z").put("ctrl", true),
            "保存" to JSONObject().put("k", "combo").put("key", "S").put("ctrl", true),
            "切窗口" to JSONObject().put("k", "combo").put("key", "TAB").put("alt", true),
        )
    }
}
